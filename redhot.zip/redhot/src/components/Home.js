import React from 'react'
import '../App.css';
import image from '../images/redhot.jpeg'

export default function Home() {
  return (
    <div class="container-fluid">

      <img src= {image} width={"100.5%"}/>
      
    </div>
  )
}
